class DesignController < ApplicationController
  layout "design"
end
