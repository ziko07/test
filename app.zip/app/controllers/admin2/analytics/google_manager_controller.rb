module Admin2::Analytics
  class GoogleManagerController < Admin2::AdminBaseController

    def index; end

  end
end
