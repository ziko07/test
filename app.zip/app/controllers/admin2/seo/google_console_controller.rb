module Admin2::Seo
  class GoogleConsoleController < Admin2::AdminBaseController

    def index; end

  end
end
