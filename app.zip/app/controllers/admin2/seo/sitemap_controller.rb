module Admin2::Seo
  class SitemapController < Admin2::AdminBaseController

    def index; end

  end
end
