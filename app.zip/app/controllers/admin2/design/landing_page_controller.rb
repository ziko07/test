module Admin2::Design
  class LandingPageController < Admin2::AdminBaseController

    def index; end

  end
end
