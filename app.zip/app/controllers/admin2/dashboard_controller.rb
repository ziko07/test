class Admin2::DashboardController < Admin2::AdminBaseController

  def index; end

end
