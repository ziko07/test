module Admin2::General
  class StaticContentController < Admin2::AdminBaseController

    def index; end

  end
end
