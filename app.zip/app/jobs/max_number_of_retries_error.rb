class MaxNumberOfRetriesError < RuntimeError; end
