module ConfigHelper
  def knowledge_base_url
    APP_CONFIG.knowledge_base_url
  end
end
