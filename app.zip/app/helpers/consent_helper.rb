module ConsentHelper
end
