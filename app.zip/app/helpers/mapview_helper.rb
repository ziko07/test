module MapviewHelper
end
