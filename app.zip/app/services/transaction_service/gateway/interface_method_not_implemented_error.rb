module TransactionService::Gateway

  class InterfaceMethodNotImplementedError < NoMethodError
  end

end
